package AbstractClassAssignment;

public abstract class Furniture {
    
    
    public String getCompanyName(){
        return "Ashley Furniture";
    }
    
    public abstract int computePrice();
}
