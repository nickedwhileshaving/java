package AbstractClassAssignment;

public class CoffeeTable extends Furniture {
    
    public int computePrice(){
        return 500;
    }
    public String getCompanyName(){
        return super.getCompanyName();
    }
    
}
