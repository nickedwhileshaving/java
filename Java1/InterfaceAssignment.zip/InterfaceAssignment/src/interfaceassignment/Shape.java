package interfaceassignment;

public interface Shape {
    
    public double PI_VALUE = Math.PI;
    public double computeArea();
}
